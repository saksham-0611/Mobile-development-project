package sessions.classes.userapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import sessions.classes.userapplication.adapters.ImageAdapter;
import sessions.classes.userapplication.models.ImageModel;

public class Verify extends AppCompatActivity {
    List<String> list;
    GridView gridview;
    ImageButton img_refresh;
    ArrayList arrayList;
    ArrayList<Integer> selectedpositions=new ArrayList<>();

    int image[] = {
            R.drawable.traffic1,
            R.drawable.traffic2,
            R.drawable.traffic3,
            R.drawable.traffic4,
            R.drawable.road1,
            R.drawable.road2,
            R.drawable.road3,
            R.drawable.park1,
            R.drawable.park2,

          };

    int count=0;
    Button btn_verify;
    CheckBox robotCheck;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify);
        list=new ArrayList<>();
        arrayList = new ArrayList<>();

        setupUI();



        for (int i = 0; i < image.length; i++) {
            ImageModel imagemodel = new ImageModel();
            imagemodel.setImage(image[i]);
            //add in array list
            arrayList.add(imagemodel);
        }

        ImageAdapter adpter= new ImageAdapter(getApplicationContext(), arrayList);
        gridview.setAdapter(adpter);
        //item click listner
        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View view, int position, long id) {


               ImageView img_tick= view.findViewById(R.id.image_tick);
               if(img_tick.getVisibility()==View.VISIBLE) {
                   img_tick.setVisibility(View.INVISIBLE);
                    count--;
                   selectedpositions.remove(position);

               }
               else {
                   img_tick.setVisibility(View.VISIBLE);
                   count++;
                   selectedpositions.add(position);
               }
            }
        });
        img_refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<Integer> myArray = new ArrayList<Integer>(9);
                for (int i = 0; i < 9; i++)
                    myArray.add(image[i]);
                Collections.shuffle(myArray);
                for(int i=0;i<myArray.size();i++)
                    image[i]=myArray.get(i);


                arrayList=new ArrayList();
                for (int i = 0; i < image.length; i++) {
                    ImageModel imagemodel = new ImageModel();
                    imagemodel.setImage(image[i]);
                    //add in array list
                    arrayList.add(imagemodel);
                }
                ImageAdapter adpter= new ImageAdapter(getApplicationContext(), arrayList);
                gridview.setAdapter(adpter);
            }
        });
        btn_verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(robotCheck.isChecked()==false)
                {
                    Toast.makeText(getApplicationContext(),"Please verify that you are not a robot",Toast.LENGTH_SHORT).show();
                    //finish();
                }
                if(count!=4)
                {
                    Toast.makeText(getApplicationContext(),"Please select 4 images",Toast.LENGTH_SHORT).show();
                    //finish();
                }

                boolean result=isVerified();
                if(result==true)
                {
                    String id=getIntent().getStringExtra("userimage");
                    Log.d("FILE",id);
                    String json="{\"userimage\":"+id+",\"name\":\""+getIntent().getStringExtra("name")+"\",\"email\":\""+getIntent().getStringExtra("email")+"\",\"phone\":\""+getIntent().getStringExtra("phone")+"\"}";
                    try {
                        save(getApplicationContext(), json);
                    }catch (Exception ee){
                        Log.d("ISSUE",ee.toString());

                    }

                    AlertDialog.Builder builder=new AlertDialog.Builder(Verify.this);
                    builder.setMessage("User Verified");
                    builder.setCancelable(false);
                    builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            finish();
                        }
                    });
                    AlertDialog alertDialog= builder.create();
                    alertDialog.setTitle("Account Status");
                    alertDialog.show();

                }
                if(result==false)
                {
                    AlertDialog.Builder builder=new AlertDialog.Builder(Verify.this);
                    builder.setMessage("User Not Verified");
                    builder.setCancelable(false);
                    builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            finish();
                        }
                    });
                    AlertDialog alertDialog= builder.create();
                    alertDialog.setTitle("Account Status");
                    alertDialog.show();

                }




            }
        });

    }
    public boolean isVerified()
    {
        int results[]=new int[4];
        int count=0;
        for(int i=0;i<9;i++)
        {
            if(image[i]==R.drawable.traffic1) {
                results[count++] = i;
            }
            if(image[i]==R.drawable.traffic2) {
                results[count++] = i;
            }
            if(image[i]==R.drawable.traffic3) {
                results[count++] = i;
            }
            if(image[i]==R.drawable.traffic4) {
                results[count++] = i;
            }
        }
        //int results[]={R.drawable.traffic1,R.drawable.traffic2,R.drawable.traffic3,R.drawable.traffic4};
        int found=0;
        for(int i=0;i<results.length;i++)
        {
            for(int j=0;j<selectedpositions.size();j++)
            {
                if(selectedpositions.get(j)==results[i]) {
                    found++;
                    break;
                }

            }

        }
        if(found==4)
            return true;
        else

        return false;
    }
    public void setupUI()

    {
        gridview = findViewById(R.id.gridview);
        img_refresh=findViewById(R.id.img_refresh);
        btn_verify=findViewById(R.id.btn_verify);
        robotCheck=findViewById(R.id.robotCheck);

    }
    public void save(Context context, String jsonString) throws IOException {
        File rootFolder = context.getExternalFilesDir(null);
         String file=read(context);
         if(file.equals(""))
             jsonString="["+jsonString+"]";
         else
            jsonString="["+ file.substring(1,file.length()-1)+","+jsonString+"]";

        File jsonFile = new File(rootFolder, "myusers.json");
        FileWriter writer = new FileWriter(jsonFile);
        writer.write(jsonString);
        writer.close();
        file=read(context);
        Log.d("FILE",file);
        //or IOUtils.closeQuietly(writer);
    }
    public String read(Context context)  {
        try {
            String jsonString = "";
            File rootFolder = context.getExternalFilesDir(null);
            File jsonFile = new File(rootFolder, "myusers.json");
            FileReader reader = new FileReader(jsonFile);
            BufferedReader br = new BufferedReader(reader);
            String filedata = "";
            while (true) {
                String line = br.readLine();
                if (line == null)
                    break;
                filedata = filedata + line;

            }
            br.close();
            reader.close();
            // Log.d("FILE",filedata);
            return filedata;
        }catch(Exception ee) {
            return "";
                }


        //or IOUtils.closeQuietly(writer);
    }
}