package sessions.classes.userapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UserDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_detail);
    }
}