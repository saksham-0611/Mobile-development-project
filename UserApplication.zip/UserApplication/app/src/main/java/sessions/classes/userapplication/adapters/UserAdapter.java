package sessions.classes.userapplication.adapters;

import android.app.Activity;
import android.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;


import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import sessions.classes.userapplication.R;
import sessions.classes.userapplication.UserDetailActivity;
import sessions.classes.userapplication.UserDetailFragment;
import sessions.classes.userapplication.models.UserModel;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {
    Context context;
    ArrayList<UserModel> models;
    int userimage[]={R.drawable.avtaar1,R.drawable.avtaar2,R.drawable.avtaar3,R.drawable.avtaar4,R.drawable.avtaar5};

    Activity parent;

    public UserAdapter(Context context, Activity parent, ArrayList<UserModel> models) {
        this.context = context;
        this.models = models;

        this.parent=parent;
    }

    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_users, parent, false));
    }

    public void onBindViewHolder(ViewHolder holder, int position) {
        UserModel model=this.models.get(position);

        holder.primaryText.setText(this.models.get(position).getName());
        holder.secondaryText.setText(this.models.get(position).getEmail());
        holder.mobileText.setText(this.models.get(position).getPhone());
        holder.profileImage.setImageDrawable(parent.getResources().getDrawable(model.getImage()));
        holder.toplayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserDetailFragment displayFrag =(UserDetailFragment) parent.getFragmentManager().findFragmentById(R.id.details_frag);
                if(displayFrag==null)
                {
                    //Toast.makeText(context,"Found",Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(context, UserDetailActivity.class);
                    intent.putExtra("name",model.getName());
                    intent.putExtra("email",model.getEmail());
                    intent.putExtra("phone",model.getPhone());
                    intent.putExtra("userimage",model.getImage());
                    context.startActivity(intent);

                }
                else
                {
                    displayFrag.updateContent(model.getName(),model.getEmail(),model.getPhone(), model.getImage());



                }
            }
        });

    }

    public int getItemCount() {
        return this.models.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
RelativeLayout toplayout;
        TextView primaryText,secondaryText,mobileText;
ImageView profileImage;
        public ViewHolder(View itemView) {
            super(itemView);
            this.primaryText =  itemView.findViewById(R.id.primaryText);
            this.secondaryText = itemView.findViewById(R.id.secondaryText);
            this.mobileText=itemView.findViewById(R.id.mobileText);
this.profileImage=itemView.findViewById(R.id.profileImage);
            toplayout=itemView.findViewById(R.id.toplayout);

        }
    }
}
