package sessions.classes.userapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterUser extends AppCompatActivity {
    Button btn_save;

    int userimage[]={R.drawable.avtaar1,R.drawable.avtaar2,R.drawable.avtaar3,R.drawable.avtaar4,R.drawable.avtaar5};

    EditText edt_name,edt_email,edt_phone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);
        setupUI();

        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(edt_name.getText().toString().equals("")) {
                    Toast.makeText(getApplicationContext(), "Please specify name", Toast.LENGTH_LONG).show();
                    return;
                }

                if(edt_email.getText().toString().equals("")) {
                    Toast.makeText(getApplicationContext(), "Please specify email", Toast.LENGTH_LONG).show();
                    return;
                }

                if(edt_phone.getText().toString().equals("")) {
                    Toast.makeText(getApplicationContext(), "Please specify phone", Toast.LENGTH_LONG).show();
                    return;
                }
                int no=(int) Math.random()*4;

Log.d("FILE",no+" ");
                Intent intent=new Intent(RegisterUser.this,Verify.class);
                intent.putExtra("name",edt_name.getText().toString());
                intent.putExtra("email",edt_email.getText().toString());
                intent.putExtra("phone",edt_phone.getText().toString());
                intent.putExtra("userimage",userimage[no]+"");
                startActivity(intent);
                finish();
            }
        });
    }
    public void setupUI()
    {
        btn_save=findViewById(R.id.btn_save);
        edt_name=findViewById(R.id.edt_name);
        edt_email=findViewById(R.id.edt_email);
        edt_phone=findViewById(R.id.edt_phone);
    }

}