package sessions.classes.userapplication;

import android.os.Bundle;

import android.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class UserDetailFragment extends Fragment {


    TextView txt_email,txt_name,txt_phone;
    ImageView image;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View rootView= inflater.inflate(R.layout.fragment_user_detail, container, false);

txt_name=rootView.findViewById(R.id.txt_name);
        txt_email=rootView.findViewById(R.id.txt_email);
        txt_phone=rootView.findViewById(R.id.txt_phone);
        image=rootView.findViewById(R.id.image);

        updateContent(getActivity().getIntent().getStringExtra("name"),getActivity().getIntent().getStringExtra("email"),getActivity().getIntent().getStringExtra("phone"),getActivity().getIntent().getIntExtra("userimage",0));
        return rootView;
    }


    public void updateContent(String name,String email,String phone,int image)
    {
            txt_name.setText(name);
            txt_email.setText(email);
            txt_phone.setText(phone);
        this.image.setImageDrawable(getActivity().getResources().getDrawable(image));


    }


}