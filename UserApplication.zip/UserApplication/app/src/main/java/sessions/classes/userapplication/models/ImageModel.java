package sessions.classes.userapplication.models;

public class ImageModel {
    int image;
    public int getImage() {
        return image;
    }
    public void setImage(int image) {
        this.image = image;
    }
}