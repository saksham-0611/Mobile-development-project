package sessions.classes.userapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

import sessions.classes.userapplication.adapters.UserAdapter;
import sessions.classes.userapplication.models.UserModel;


public class UsersFragment extends Fragment {


    View rootView;
    ArrayList<UserModel> users;
    Button btn_adduser;
    RecyclerView recyclerView;
    EditText edt_name,edt_email,edt_phone;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
         rootView=inflater.inflate(R.layout.fragment_users, container, false);
        setupUI();


        btn_adduser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(),RegisterUser.class);
                startActivity(intent);
            }
        });

        getUsers();

        return rootView;
    }
    public void getUsers()
    {
        users=new ArrayList<>();
        String response= readFromJson(getContext());
        Log.d("FILE",response);
        try {
            JSONArray array=new JSONArray(response);

            for(int i=0;i<array.length();i++)
            {
                JSONObject obj=array.getJSONObject(i);
                UserModel userModel=new UserModel();
                userModel.setName(obj.getString("name"));
                userModel.setEmail(obj.getString("email"));
                userModel.setPhone(obj.getString("phone"));
                userModel.setImage(obj.getInt("userimage"));
                users.add(userModel);

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        setAdapter();
    }
    public void setAdapter()
    {
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);


        UserAdapter adapter = new UserAdapter(getContext(),getActivity(), users);
        recyclerView.setAdapter(adapter);

    }
    public void    setupUI()
    {
        btn_adduser=rootView.findViewById(R.id.btn_adduser);
        recyclerView=rootView.findViewById(R.id.recyclerView);
    }
    public String readFromJson(Context context)  {
        try {
            String jsonString = "";
            File rootFolder = context.getExternalFilesDir(null);
            File jsonFile = new File(rootFolder, "myusers.json");
            FileReader reader = new FileReader(jsonFile);
            BufferedReader br = new BufferedReader(reader);
            String filedata = "";
            while (true) {
                String line = br.readLine();
                if (line == null)
                    break;
                filedata = filedata + line;

            }
            br.close();
            reader.close();
            // Log.d("FILE",filedata);
            return filedata;
        }catch(Exception ee) {
            return "[]";
        }


        //or IOUtils.closeQuietly(writer);
    }
    @Override
    public void onResume()
    {
        getUsers();
        super.onResume();
    }


}